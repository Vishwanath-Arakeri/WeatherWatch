import requests
from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.contrib.auth.decorators import login_required
from .models import City
# Create your views here.

@login_required(login_url='login')
def HomePage(request):
    cities=City.objects.all()
    weather_data=[]
    for city in cities:
        api_key="pyDot4beUj1Sx1EDXNJanxRTAZ5xm9tk"
        city="Delhi"
        city_search_base_url="http://dataservice.accuweather.com/locations/v1/cities/search"
        citykey= requests.get(city_search_base_url+"?"+"apikey="+api_key+"&q="+city).json()[0]["Key"]
        #print(type(citykey),citykey)
        fore_cast_base_url="http://dataservice.accuweather.com/forecasts/v1/daily/1day/"
        fore_cast=requests.get(fore_cast_base_url+citykey+"?"+"apikey="+api_key).json()
        description=fore_cast['Headline']['Text']
        temperature=str(fore_cast['DailyForecasts'][0]['Temperature']['Minimum']['Value'])+" °F to"+" " +str(fore_cast['DailyForecasts'][0]['Temperature']['Maximum']['Value'])+" °F"
        day=fore_cast["DailyForecasts"][0]["Day"]["IconPhrase"]
        night=fore_cast["DailyForecasts"][0]["Night"]["IconPhrase"]
        city_weather={'city': city,
                    'description':description,
                    'temperature': temperature,
                    'day': day,
                    'night':night
                    }
        print(city_weather)
        weather_data.append(city_weather)
    context={"weather_data":weather_data}
    return render(request,'home.html',context)

def SignupPage(request):
    if request.method=="POST":
        uname=request.POST.get("username")
        email=request.POST.get("email")
        pass1=request.POST.get("password1")
        pass2=request.POST.get("password2")
        if pass1!=pass2:
            return HttpResponse("Passwords do not match")
        else:
            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect("login")
    return render(request,'signup.html')

def LoginPage(request):
    if request.method=="POST":
        username=request.POST.get("username")
        pass1=request.POST.get("pass")
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return HttpResponse("Username or Password is incorrect")
    return render(request,'login.html')
    
def search_weather(request):
    location = request.POST.get('location')
    print("location")
    return render(request,'WeatherHome.html')

def LogoutPage(request):
    return redirect('login')